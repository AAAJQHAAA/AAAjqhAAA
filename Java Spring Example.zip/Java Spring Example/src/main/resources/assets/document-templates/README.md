## Overview

Template files used to create new documents and documents with sample content in: 

* [Document Server integration example](https://github.com/ONLYOFFICE/document-server-integration)



